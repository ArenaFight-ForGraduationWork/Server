#include <iostream>
#include <thread>
#include <WinSock2.h>
#include <Windows.h>
#include <vector>
#include <set>
#include <mutex>
#include <string>
#include <thread>
#include "protocol.h"
#include <conio.h>
#include <cstdio>
using namespace std;


HINSTANCE g_hlnst;
LPCTSTR lpszClass = "Window Class Name";
SOCKET sock;
HDC hdc;
HDC mem1dc;
HDC mem2dc;
HBITMAP hBit, oldBit, oldBitObject;
char ip[16];
bool server_on = false;
int current_other_count = -1;
packet_player_move* move_packet;
int volatile timerd;
int volatile timerother;

WSABUF   send_wsabuf;
char    send_buffer[MAX_BUFF_SIZE];
WSABUF   recv_wsabuf;
char   recv_buffer[MAX_BUFF_SIZE];
char   packet_buffer[MAX_BUFF_SIZE];
DWORD   in_packet_size = 0;
int      saved_packet_size = 0;
int      myid;
int npc_count = 0;
void ReadPacket ();
void ProcessPacket (char *ptr);
DWORD WINAPI recvThread (LPVOID arg);
LRESULT CALLBACK WndProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

Player player;
Player other[10];
Player boss;

bool volatile dead = true;
void err_quit (char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage (
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError (),
		MAKELANGID (LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf, 0, NULL);
	MessageBox (NULL, (LPCTSTR) lpMsgBuf, msg, MB_ICONERROR);
	LocalFree (lpMsgBuf);
	exit (-1);
}

// ���� �Լ� ���� ���
void err_display (char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage (
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError (),
		MAKELANGID (LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf, 0, NULL);
	printf ("[%s] %s", msg, (LPCTSTR) lpMsgBuf);
	LocalFree (lpMsgBuf);
}
void ServerConnect () {
	int retval;

	// ���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup (MAKEWORD (2, 2), &wsa) != 0)
		return;

	// socket()
	sock = socket (AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET) err_quit ("socket()");

	// connect()
	SOCKADDR_IN serveraddr;
	ZeroMemory (&serveraddr, sizeof (serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = inet_addr (ip);
	serveraddr.sin_port = htons (SERVER_PORT);
	retval = connect (sock, (SOCKADDR *) &serveraddr, sizeof (serveraddr));
	if (retval == SOCKET_ERROR) err_quit ("connect()");
	server_on = true;
	//ReadPacket();
}

int WINAPI WinMain (HINSTANCE hlnstance, HINSTANCE hPrevlnstance, LPSTR lpszCmdParam, int nCmdShow) {
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass; //WNDCLASSEX �̸� 12���� WNDCLASS �̸� 10����
	g_hlnst = hlnstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH);
	WndClass.hCursor = LoadCursor (NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon (NULL, IDI_APPLICATION);
	WndClass.hInstance = hlnstance;
	WndClass.lpfnWndProc = (WNDPROC) WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass (&WndClass);

	hWnd = CreateWindow (lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 567, 590, NULL, (HMENU) NULL, hlnstance, NULL);

	ShowWindow (hWnd, nCmdShow);
	UpdateWindow (hWnd);

	while (GetMessage (&Message, 0, 0, 0)) {
		TranslateMessage (&Message);
		DispatchMessage (&Message);
	}
	return Message.wParam;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

	
	PAINTSTRUCT ps;
	HBRUSH hBrush, oldBrush, kBrush;
	RECT rect;

	static SIZE size;

	static int count;
	static int retval;
	static char buf[200];
	static int check = 0;
	static int check1 = 0;
	rect.left = 400;
	rect.top = 180;
	rect.right = 600;
	rect.bottom = 200;
	static HANDLE recv_thread;
	switch (uMsg) {
		case WM_CREATE:
			CreateCaret (hwnd, NULL, 3, 15);
			ShowCaret (hwnd);
			break;
		case WM_PAINT:
			hdc = BeginPaint(hwnd, &ps);
			mem1dc = CreateCompatibleDC(hdc);
			hBit = CreateCompatibleBitmap(hdc, 500, 500);
			oldBit = (HBITMAP)SelectObject(mem1dc, hBit);
			mem2dc = CreateCompatibleDC(hdc);

			Rectangle(mem1dc, -10,-100, 550,550);

			if (server_on) {
				kBrush = CreateSolidBrush (RGB (255, 0, 0));
				oldBrush = (HBRUSH) SelectObject (mem1dc, kBrush);
				if (player.on == true) {
					Rectangle(mem1dc, (player.x), (player.z), (player.x) + 50, (player.z) + 50);
				}

				SelectObject(mem1dc, oldBrush);
				DeleteObject(kBrush);


				kBrush = CreateSolidBrush(RGB(0, 255, 0));
				oldBrush = (HBRUSH)SelectObject(mem1dc, kBrush);
				for (int i = 0; i < 10; ++i) {
					if (other[i].on == true) {
						Rectangle(mem1dc, (other[i].x), (other[i].z), (other[i].x) + 50, (other[i].z) + 50);
					}
				}
				SelectObject(mem1dc, oldBrush);
				DeleteObject(kBrush);

				kBrush = CreateSolidBrush(RGB(0, 0, 255));
				oldBrush = (HBRUSH)SelectObject(mem1dc, kBrush);
				if (player.on == true) {
					Ellipse(mem1dc, (boss.x), (boss.z), (boss.x) + 50, (boss.z) + 50);
				}
				SelectObject(mem1dc, oldBrush);
				DeleteObject(kBrush);


				wsprintf(buf, "MY");
				TextOut(mem1dc, player.x, player.z,  buf, strlen(buf));
			}
			else {
				GetTextExtentPoint(mem1dc, ip, strlen(ip), &size);
				hBrush = CreateSolidBrush(RGB(255, 0, 0));
				oldBrush = (HBRUSH)SelectObject(mem1dc, hBrush);
				DrawText(mem1dc, ip, strlen(ip), &rect, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
				TextOut(mem1dc, 400, 160, "�������Է�", 10);
				FrameRect(mem1dc, &rect, hBrush);
				SetCaretPos(size.cx + 400, 183);
				SelectObject(mem1dc, oldBrush);
				DeleteObject(hBrush);
				HideCaret(hwnd);
			}

			BitBlt(hdc, 0, 0, 500, 500, mem1dc, 0, 0, SRCCOPY);
			DeleteObject(mem2dc);
			SelectObject(mem1dc, oldBit);
			DeleteObject(hBit);
			DeleteDC(mem1dc);
			EndPaint(hwnd, &ps);
			break;
		case WM_TIMER:
			switch (wParam) {
				case 1:
					recv_thread = CreateThread (NULL, 0, recvThread, NULL, 0, 0);
					break;
			}
			InvalidateRgn(hwnd, NULL, FALSE);
			break;
		case WM_CHAR:
			if (server_on == false) {
				if (wParam == VK_RETURN) {
					sscanf (ip, "%s", &ip);
					ServerConnect();
					SetTimer (hwnd, 1, 10, NULL);
				}
				else if (wParam == VK_BACK) {
					if (count == 0) {
						break;
					}
					else {
						count--;
						ip[count] = '\0';
					}
				}
				else {
					if (strlen (ip) > 14) {
						break;
					}
					else {
						ip[count++] = wParam;
						ip[count] = '\0';
					}
				}
				InvalidateRgn(hwnd, NULL, FALSE);
			}
			break;
		case WM_KEYDOWN:
			if (server_on == true) {
				if (dead == true) {
					move_packet = reinterpret_cast<packet_player_move*>(send_buffer);
					if (wParam == VK_UP) {
						move_packet->size = sizeof(*move_packet);
						move_packet->type = PLAYER_MOV;
						move_packet->move_type = 1;
						retval = send(sock, (char*)move_packet, sizeof(*move_packet), 0);
					}
					else if (wParam == VK_DOWN) {
						move_packet->size = sizeof(*move_packet);
						move_packet->type = PLAYER_MOV;
						move_packet->move_type = 2;
						retval = send(sock, (char*)move_packet, sizeof(*move_packet), 0);
					}
					else if (wParam == VK_LEFT) {
						move_packet->size = sizeof(*move_packet);
						move_packet->type = PLAYER_MOV;
						move_packet->move_type = 3;
						retval = send(sock, (char*)move_packet, sizeof(*move_packet), 0);
					}
					else if (wParam == VK_RIGHT) {
						move_packet->size = sizeof(*move_packet);
						move_packet->type = PLAYER_MOV;
						move_packet->move_type = 4;
						retval = send(sock, (char*)move_packet, sizeof(*move_packet), 0);
					}
					//timerd = GetTickCount();
					/*if (move_packet->move_type == 1) {
						player.z -= 10;
					}
					else if (move_packet->move_type == 2) {
						player.z += 10;
					}
					else if (move_packet->move_type == 3) {
						player.x -= 10;
					}
					else if (move_packet->move_type == 4) {
						player.x += 10;
					}*/
				}
				dead = false;
				/*
				if (timerd <= GetTickCount()) {
					if (move_packet->move_type == 1) {
							player.z -= 15;
					}
					else if (move_packet->move_type == 2) {
							player.z += 15;
					}
					else if (move_packet->move_type == 3) {
							player.x -= 15;
					}
					else if (move_packet->move_type == 4) {
							player.x += 15;
					}
					timerd = GetTickCount() + 300;
				}*/
			}
			InvalidateRgn(hwnd, NULL, FALSE);
			break;

		case WM_KEYUP:
			if (server_on == true) {
				if (wParam == VK_UP) {
					packet_player_move* pp = reinterpret_cast<packet_player_move*>(send_buffer);
					pp->size = sizeof(*pp);
					pp->type = PLAYER_MOV_END;
					pp->move_type = 1;
					retval = send(sock, (char*)pp, sizeof(*pp), 0);
				}
				else if (wParam == VK_DOWN) {
					packet_player_move* pp = reinterpret_cast<packet_player_move*>(send_buffer);
					pp->size = sizeof(*pp);
					pp->type = PLAYER_MOV_END;
					pp->move_type = 2;
					retval = send(sock, (char*)pp, sizeof(*pp), 0);
				}
				else if (wParam == VK_LEFT) {
					packet_player_move* pp = reinterpret_cast<packet_player_move*>(send_buffer);
					pp->size = sizeof(*pp);
					pp->type = PLAYER_MOV_END;
					pp->move_type = 3;
					retval = send(sock, (char*)pp, sizeof(*pp), 0);
				}
				else if (wParam == VK_RIGHT) {
					packet_player_move* pp = reinterpret_cast<packet_player_move*>(send_buffer);
					pp->size = sizeof(*pp);
					pp->type = PLAYER_MOV_END;
					pp->move_type = 4;
					retval = send(sock, (char*)pp, sizeof(*pp), 0);
				}

				dead = true;
			}
			InvalidateRgn (hwnd, NULL, FALSE);
			break;
		case WM_DESTROY:
			PostQuitMessage (0);
			break;
	}
	return DefWindowProc (hwnd, uMsg, wParam, lParam);
}


void ProcessPacket (char *ptr) {
	switch (ptr[1]) {
	case LOGIN:
	{
		login *my_packet = reinterpret_cast<login *>(ptr);
		myid = my_packet->yourid;
		player.id = myid;
		player.on = true;
		for (int i = 0; i < my_packet->count; ++i) {

			current_other_count++;
			other[current_other_count].id = my_packet->id[i];
			other[current_other_count].x = my_packet->x[i];
			other[current_other_count].z = my_packet->z[i];

			other[current_other_count].on = true;
		}
		break;
	}
	case PUT_PLAYER:
	{
		player_position *my_packet = reinterpret_cast<player_position *>(ptr);

		current_other_count++;
		other[current_other_count].on = true;
		other[current_other_count].id = my_packet->id;
		other[current_other_count].x = my_packet->x;
		other[current_other_count].z = my_packet->z;
		break;
	}
	case PLAYER_POS:
	{
		player_position *my_packet = reinterpret_cast<player_position *>(ptr);
		if (my_packet->id == myid) {
			player.x = my_packet->x;
			player.z = my_packet->z;
		}
		else {
			for (int i = 0; i < 10; ++i) {
				if (my_packet->id == other[i].id) {
					/*timerother = GetTickCount();
					int temp = timerother;
					while (timerother <= temp + 280 ) {
						if (timerother <= GetTickCount()) {
							if (my_packet->move_type == 1) {
								other[i].z -= 15;
							}
							else if (my_packet->move_type == 2) {
								other[i].z += 15;
							}
							else if (my_packet->move_type == 3) {
								other[i].x -= 15;
							}
							else if (my_packet->move_type == 4) {
								other[i].x += 15;
							}
							timerother = GetTickCount() + 280;
						}
					}*/
					other[i].x = my_packet->x;
					other[i].z = my_packet->z;
					break;
				}
			}
		}
		break;
	}
	case BOSS_POS:
	{
		player_position *my_packet = reinterpret_cast<player_position *>(ptr);
		boss.x = my_packet->x;
		boss.z = my_packet->z;

		break;
	}
	default:
		printf ("Unknown PACKET type [%d]\n", ptr[1]);
	}
}

DWORD WINAPI recvThread (LPVOID arg) {
	while (1) {
		recv_wsabuf.buf = recv_buffer;
		recv_wsabuf.len = MAX_BUFF_SIZE;
		DWORD iobyte, ioflag = 0;

		int ret = WSARecv (sock, &recv_wsabuf, 1, &iobyte, &ioflag, NULL, NULL);
		if (ret) {
			int err_code = WSAGetLastError ();
			printf ("Recv Error [%d]\n", err_code);
			return 0;
		}

		BYTE *ptr = reinterpret_cast<BYTE *>(recv_buffer);
		while (0 != iobyte) {
			if (0 == in_packet_size) in_packet_size = ptr[0];
			if (iobyte + saved_packet_size >= in_packet_size) {
				memcpy (packet_buffer + saved_packet_size, ptr, in_packet_size - saved_packet_size);
				ProcessPacket (packet_buffer);
				ptr += in_packet_size - saved_packet_size;
				iobyte -= in_packet_size - saved_packet_size;
				in_packet_size = 0;
				saved_packet_size = 0;
			}
			else {
				memcpy (packet_buffer + saved_packet_size, ptr, iobyte);
				saved_packet_size += iobyte;
				iobyte = 0;
			}
		}
	}
	return 0;
}
void ReadPacket () {
	while (true) {
		recv_wsabuf.buf = recv_buffer;
		recv_wsabuf.len = MAX_BUFF_SIZE;
		DWORD iobyte, ioflag = 0;

		int ret = WSARecv (sock, &recv_wsabuf, 1, &iobyte, &ioflag, NULL, NULL);
		if (ret) {
			int err_code = WSAGetLastError ();
			printf ("Recv Error [%d]\n", err_code);
		}

		BYTE *ptr = reinterpret_cast<BYTE *>(recv_buffer);
		while (0 != iobyte) {
			if (0 == in_packet_size) in_packet_size = ptr[0];
			if (iobyte + saved_packet_size >= in_packet_size) {
				memcpy (packet_buffer + saved_packet_size, ptr, in_packet_size - saved_packet_size);
				ProcessPacket (packet_buffer);
				ptr += in_packet_size - saved_packet_size;
				iobyte -= in_packet_size - saved_packet_size;
				in_packet_size = 0;
				saved_packet_size = 0;
			}
			else {
				memcpy (packet_buffer + saved_packet_size, ptr, iobyte);
				saved_packet_size += iobyte;
				iobyte = 0;
			}
		}
	}
}